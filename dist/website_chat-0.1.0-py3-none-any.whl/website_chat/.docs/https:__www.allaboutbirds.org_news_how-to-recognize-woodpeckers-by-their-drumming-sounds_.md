[Skip to main content](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/#main-content)
[Skip to Content Area](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/#main-content)
  * [Get Involved](https://www.allaboutbirds.org/news/get-involved/)
  * [Get eNews](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/)
  * [Donate](https://give.birds.cornell.edu/page/87895/donate/1?ea.tracking.id=AAB)


[ ![Cornell Lab | All About Birds](https://www.allaboutbirds.org/news/wp-content/uploads/2024/02/clo_allaboutbirds_stacked.svg) ![Cornell Lab | All About Birds](https://www.allaboutbirds.org/news/wp-content/uploads/2024/02/clo_allaboutbirds_short.svg) ![Cornell Lab | All About Birds](https://www.allaboutbirds.org/news/wp-content/uploads/2024/02/clo_allaboutbirds_short.svg) ](https://www.allaboutbirds.org/news/ "Return Home")
  * [Birds](https://www.allaboutbirds.org/guide/)
    * [Bird Guide](https://www.allaboutbirds.org/guide/)
    * [Bird ID Skills](https://www.allaboutbirds.org/news/browse/topic/bird-id-skills/)
    * [Feeding Birds](https://www.allaboutbirds.org/news/browse/topic/feeding-birds/)
    * [Bird-Friendly Homes](https://www.allaboutbirds.org/news/browse/topic/bird-friendly-homes/)
    * [Binoculars & Gear](https://www.allaboutbirds.org/news/browse/topic/binoculars-and-gear/)
    * [Sounds & Songs](https://www.allaboutbirds.org/news/browse/topic/sounds-songs/)
    * [FAQs & Problems](https://www.allaboutbirds.org/news/browse/topic/faqs/)
    * [Festivals & Events](https://www.allaboutbirds.org/news/birding-festivals?utm_source=global-nav)
    * [About Cornell Lab](https://www.allaboutbirds.org/news/about-the-cornell-lab-of-ornithology/)
  * [Live Cams](https://www.allaboutbirds.org/cams/)
    * [Barred Owls](https://www.allaboutbirds.org/cams/barred-owls/)
    * [Great Horned Owls](https://www.allaboutbirds.org/cams/wildflower-great-horned-owls/)
    * [Red-tailed Hawks](https://www.allaboutbirds.org/cams/red-tailed-hawks/)
    * [Royal Albatross](https://www.allaboutbirds.org/cams/royal-albatross/)
    * [Cornell Lab FeederWatch](https://www.allaboutbirds.org/cams/cornell-lab-feederwatch/)
    * [All Cams](https://www.allaboutbirds.org/cams/all-cams/)
  * [Courses](https://academy.allaboutbirds.org/?utm_source=aab)
    * [Bird Identification](https://academy.allaboutbirds.org/course-list/?category=bird-identification&order=featured&utm_source=aab)
    * [Bird Biology](https://academy.allaboutbirds.org/course-list/?category=bird-biology&order=featured&utm_source=aab)
    * [Learning Games](https://academy.allaboutbirds.org/learning-games/?utm_source=aab)
    * [How to Use eBird](https://academy.allaboutbirds.org/product/ebird-essentials/?utm_source=aab)
    * [Learn Bird Songs](https://academy.allaboutbirds.org/product/be-a-better-birder-how-to-identify-bird-songs/?utm_source=aab)
    * [All Online Courses](https://academy.allaboutbirds.org/course-list/?utm_source=aab)
  * [Merlin Bird ID](https://merlin.allaboutbirds.org/)


  * [Get Involved](https://www.allaboutbirds.org/news/get-involved/)
  * [Get eNews](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/)
  * [Donate](https://give.birds.cornell.edu/page/87895/donate/1?ea.tracking.id=AAB)


Search
Menu
# How to Recognize Woodpeckers by Their Drumming Sounds
Woodpecker drumming may not be as immediately distinctive as birdsong—but by carefully listening to speed, duration, and rhythm you can still tell many species apart. Here are some tips.
April 3, 2025
Share: [](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/) [](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/)
Downy Woodpeckers have short, relatively slow drums. Video by Seth Honig / Macaulay Library.
One of the first indications of springtime in North America is the rat-a-tat sound of woodpeckers drumming. Even on mild, sunny days in late winter you may hear them trying out their drumming. Compared with the melody and tone of birdsong, drumming isn’t quite as recognizable—but if you listen closely you can still tell some woodpeckers apart from others.
Woodpeckers can drum all year round, but there’s a noticeable uptick during the spring months—roughly March through June depending on your latitude. In woodpeckers, drumming serves the same function as song does for songbirds: it advertises a bird’s (or a pair’s) territory and helps attract mates. In most woodpecker species, both males and females drum.
## How and Why Do Woodpeckers Drum?
Anytime you hear a fast, extended sequence of loud pecks—that’s drumming, and it’s all about communication. They’re not looking for food. In fact, during feeding woodpeckers peck slowly and make only faint noises as they choose when and where to take their next strike. (Listening out for these quiet, methodical pecking sounds can be helpful in tracking down a woodpecker as it’s busy feeding.)
This also explains why you often see woodpeckers drumming on metal surfaces like streetlights, gutters, and garbage can lids. They’re not confused about where their dinner is, they’re looking to make the loudest possible sound. If you watch a woodpecker drumming on a dead tree, you’ll often see it make minute adjustments in where it’s pecking. Sometimes a slight adjustment results in a much louder, farther-carrying sound.
## 3 Main Drumming Patterns
### Rat-a-tat-tat: Steady, Evenly Spaced Drumming
The classic woodpecker drum is a steady delivery of fast strikes on a hard surface. Many woodpeckers drum this way, so it may seem difficult to identify them to species. But take heart—species that occur in the same regions of North America often sound different. It’s especially important to pay attention to **speed** and **duration** of the drumming.
#### Downy vs. Hairy Woodpeckers
Two of North America’s most widespread woodpeckers, Downy and Hairy, are commonly found together. Listen for the faster pace of the Hairy to tell them apart. It can be really helpful to look at spectrograms while listening to audio recordings, to help you pick out details of the sounds. Here’s [more on how to read spectrograms](https://www.allaboutbirds.org/news/how-to-learn-bird-songs-and-calls#spectrograms).
![A black and white bird with a small, sharp bill perches on a tree that has bark removed from the bird's foraging.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/314690121-Downy_Woodpecker-Adam_Perrier-1280x960.jpg)_Downy Woodpecker by[Adam Perrier / Macaulay Library](https://macaulaylibrary.org/asset/314690121/)._
[Downy Woodpeckers](https://allaboutbirds.org/guide/downy_woodpecker/sounds) have a relatively slow delivery (about 17 beats per second, according to [Birds of the World](https://birdsoftheworld.org/bow/species/dowwoo/cur/introduction)). It sounds like you could _almost_ count each strike as it comes through. Downy Woodpecker drums are short, averaging about 0.8 seconds.
![A black and white bird with a red head patch and sharp bill perches on a tree that has bark removed from the bird's foraging.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/612806815-Hairyy_Woodpecker-Erica_Heusser-1280x960.jpg)_Hairy Woodpecker by[Erica Heusser / Macaulay Library](https://macaulaylibrary.org/asset/612806815/)._
The very similar [Hairy Woodpecker](https://allaboutbirds.org/guide/hairy_woodpecker/sounds) drums faster (about 26 beats per second), and a bit longer (averaging 1 second) than Downy. It’s impossible to count the pecks as they happen. You can see the difference in these spectrograms—the lines indicating each strike are packed tighter together than in the Downy.
#### Nuttall’s vs. Ladder-backed Woodpeckers 
In the southwestern U.S., Nuttall’s and Ladder-backed Woodpeckers can sometimes occur near each other. Like the Downy and Hairy, the difference in their drumming speed is noticeable.
![A black and white bird with a red head patch and sharp bill perches on a tree that has bark removed, possibly from the bird's nest excavating.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/618750840-Nuttalls_Woodpecker-Braxton_Landsman-1280x960.jpg)_Nuttall’s Woodpecker by[Braxton Landsman / Macaulay Library](https://macaulaylibrary.org/asset/618750840/)._
[Nuttall’s Woodpeckers](https://allaboutbirds.org/guide/nuttalls_woodpecker/sounds) have an intermediate delivery (about 20 beats per second), slightly faster than a Downy Woodpecker. Drums average about 1 second long, so there’s enough overlap with Downy Woodpecker that it is hard to tell these two species apart. But with practice the faster cadence of Hairy and Ladder-backed should be noticeable.
![A black and white bird with a red head cap and sharp bill perches on a tree.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/318889051-Ladder-backed_Woodpecker-Shailesh_Pinto-1280x960.jpg)_Ladder-backed Woodpecker by[Shailesh Pinto / Macaulay Library](https://macaulaylibrary.org/asset/318889051/)._
[Ladder-backed Woodpeckers](https://allaboutbirds.org/guide/ladder-backed_woodpecker/sounds) drum really fast—at about 30 beats per second, they’re even faster than a Hairy. It almost runs together into a single continuous sound. The speed of the delivery is noticeable in the spectrogram, with the lines indicating each peck packed very close together.
#### Northern Flicker
With [Northern Flickers](https://allaboutbirds.org/guide/northern_flicker/sounds), each bout of drumming usually lasts for longer than a second—longer than many other species. [In a spectrogram](https://macaulaylibrary.org/asset/94346) you can see how the cluster of lines indicating pecks is longer.
Northern Flickers drum at about 23 beats per second—faster than Downy, but only slightly slower than Hairy. Flickers often pause between drums and give their long, piping call, which also helps with recognition.
### Stutterstep Rhythms: Sapsuckers
The complex rhythm of sapsucker drumming is instantly recognizable: an introductory roll followed by unevenly spaced beats consisting of very fast multiple taps. Sapsuckers are migratory, and when they return to breeding grounds their off-kilter drumming sound is for many birders a welcome sound of early springtime. 
![Black and white patterned bird with a yellowish underside and a red cap and red neck, perches on a tree.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/431705101-Yellow-bellied_Sapsucker-Daniel_S-1280x960.jpg)_Yellow-bellied Sapsucker by[Daniel S. / Macaulay Library](https://macaulaylibrary.org/asset/431705101/)._
The closely related [Yellow-bellied](https://allaboutbirds.org/guide/yellow-bellied_sapsucker/sounds), [Red-naped](https://allaboutbirds.org/guide/red-naped_sapsucker/sounds), and [Red-breasted](https://allaboutbirds.org/guide/red-breasted_sapsucker/sounds) Sapsuckers (once considered a single species) have very similar drumming patterns. (Fortunately, their breeding ranges have very little overlap.) After the initial drumroll, they give double taps at irregular intervals that slowly space out. The double taps are so fast that on the spectrogram they almost look like a single strike.
![Black and white patterned bird with a yellowish underside, a red neck patch, and black and white stripes on face, perches on a tree.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/497962121-Williamsons_Sapsucker-Blair_Dudeck-1280x960.jpg)_Williamson’s Sapsucker by[Blair Dudeck / Macaulay Library](https://macaulaylibrary.org/asset/497962121/)._
[Williamson’s Sapsuckers](https://allaboutbirds.org/guide/williamsons_sapsucker/sounds) occur in mountains of western North America where they may overlap with Red-naped and Red-breasted Sapsuckers. Their drum is slightly different: after the initial drumroll, the ensuing beats consist of multiple (not doubled) hits. These beats get more widely spaced and softer as the drum goes on. 
### Fadeaways: Drumming that Trails Off at the End
The widespread [Pileated Woodpecker](https://allaboutbirds.org/guide/pileated_woodpecker/sounds) has a distinctive drum befitting the bird’s size and power. These crow-sized woodpeckers often drum on large trees and produce a deep, powerful sound. 
Pileated Woodpeckers drum slowly (about 15 beats per second), with slightly faster sections at the beginning and end that create a sense of the sound building up and then fading away.
Two uncommon species, Black-backed and American Three-toed Woodpeckers, are often sought after by birders. Their distinctive drumming can help you locate them once you’ve found the correct habitat. 
![Black and white bird with a yellow spot on head, perches on the side of a tree.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/630522022-American_Three-toed_Woodpecker-Melissa_James-1280x960.jpg)_American Three-toed Woodpecker by[Melissa James / Macaulay Library](https://macaulaylibrary.org/asset/630522022/)._
[American Three-toed Woodpeckers](https://allaboutbirds.org/guide/american_three-toed_woodpecker/sounds) have a fairly long, slow drum—lasting 1.3 seconds or more with and with about 14 beats per second. The drumming speeds up noticeably at the end, creating a sense of the sound fading away. If you look closely at a spectrogram, you can see the space between the strikes shorten toward the end of the drum.
![Black and white bird with a yellow spot on head, perches on the side of a tree.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/04/632175187-Black-backed_Woodpecker-Patricia_Patterson-1280x960.jpg)_Black-backed Woodpecker by[Patricia Patterson / Macaulay Library](https://macaulaylibrary.org/asset/632175187/)._
The slightly larger [Black-backed Woodpecker](https://allaboutbirds.org/guide/black-backed_woodpecker/sounds) drums faster and for longer than American Three-toed Woodpecker. Drums last for about 1.9 seconds—among the longest of the woodpeckers mentioned in this article—and they strike the tree at about 16 beats per second. The drum speeds up slightly at the end and the volume often trails off, giving a fadeaway effect.
_Sources: Data on drumming speed and pattern come from the[Birds of the World](https://birdsoftheworld.org/bow/home) accounts for each species._
## Related Stories
Previous
  * ![A brown-gray bird with an open bill pokes its head out of a tree while pecking the tree to open up a cavity.](https://www.allaboutbirds.org/news/wp-content/uploads/2025/03/Northern_Flicker-Michael_Quinton-Minden-FI.jpg)
[The Hole Story: How Woodpeckers Make Homes for the Rest of the Forest](https://www.allaboutbirds.org/news/hole-story-how-woodpeckers-make-homes-forest/)
  * ![](https://www.allaboutbirds.org/news/wp-content/uploads/2023/02/Acorn_Woodpecker-Sulivan4x3.jpg)
[Why do woodpeckers like to hammer on houses? And what can I do about it?](https://www.allaboutbirds.org/news/why-do-woodpeckers-like-to-hammer-on-houses-and-what-can-i-do-about-it/)
  * ![A bright yellow bird sings while perches on a dead log.](https://www.allaboutbirds.org/news/wp-content/uploads/2024/05/438159401-Prothonotary_Warbler-Ryan_Justice-FI.jpg)
[Bird ID Skills: How to Learn Bird Songs and Calls](https://www.allaboutbirds.org/news/how-to-learn-bird-songs-and-calls/)
  * ![Hairy Woodpecker, by Mike Bons](https://www.allaboutbirds.org/news/wp-content/uploads/2018/02/HWoodpecker-Leighton.jpg)
[Why do Downy and Hairy Woodpeckers look so similar when they aren’t close relatives?](https://feederwatch.org/blog/downy-hairy-woodpeckers-look-similar-arent-close-relatives/)
  * ![photogenic Acorn Woodpecker](https://www.allaboutbirds.org/news/wp-content/uploads/2015/06/nutty1_summer2011.jpg)
[Going Nutty for Acorn Woodpeckers](https://www.allaboutbirds.org/news/going-nutty-for-acorn-woodpeckers/)
Next
    * Go to slide 1
    * Go to slide 2


![The Cornell Lab](https://www.allaboutbirds.org/news/wp-content/uploads/2025/01/clo_primary_black.png)
## All About Birds  
is a free resource
Available for everyone,  
funded by donors like you
[Donate](https://give.birds.cornell.edu/page/87895/donate/1?ea.tracking.id=AAB)
American Kestrel by [Blair Dudeck / Macaulay Library](https://macaulaylibrary.org/asset/416935361)
## Related Stories
  * [ ![A blue, gray and black bird sits on a peanut-filled bird feeder and holds a peanut in its beak.](https://www.allaboutbirds.org/news/wp-content/uploads/2024/08/BLue_Jay-Melissa_Rowell-PFW-top-480x360.jpg) How to Choose the Right Kind of Bird Feeder ](https://www.allaboutbirds.org/news/how-to-choose-the-right-kind-of-bird-feeder/)
  * [ ![A small brownish streaky bird.](https://www.allaboutbirds.org/news/wp-content/uploads/2009/04/YRWarbler-Seitz-143912041-e1676334957265-480x361.jpg) What's the best book or field guide for bird identification? ](https://www.allaboutbirds.org/news/whats-the-best-book-or-field-guide-for-bird-identification/)
  * [ ![Gray/blue, white, orange bird on a branch.](https://www.allaboutbirds.org/news/wp-content/uploads/2021/06/NParula-Sanderson-MLFI2-480x360.jpg) At Orchards and Vineyards, Birds Are Outperforming Pesticides Living Bird Magazine ](https://www.allaboutbirds.org/news/at-orchards-and-vineyards-birds-are-outperforming-pesticides/)
  * [ ![A bright red male Northern Cardinal on a snowy log. Photo by Brad Imhoff/Macaulay Library.](https://www.allaboutbirds.org/news/wp-content/uploads/2021/12/288821651-Northern_Cardinal-Imhoff-FI-480x360.jpg) Are Cardinals Redder in Winter? ](https://www.allaboutbirds.org/news/are-cardinals-brighter-in-winter/)


[ ![The Cornell Lab of Ornithology](https://www.allaboutbirds.org/news/wp-content/themes/birdpress3/images/cornell-lab-logo-full-white.svg) ](http://www.birds.cornell.edu/ "The Cornell Lab of Ornithology")
  * [About Us](https://www.birds.cornell.edu/home/about/)
    * [Overview](https://www.birds.cornell.edu/home/about/)
    * [Programs](https://www.birds.cornell.edu/home/about/programs/)
    * [Visit the Lab](https://www.birds.cornell.edu/home/visit/)
    * [Job Opportunities](https://www.birds.cornell.edu/home/jobs/)
    * [News Releases](https://www.birds.cornell.edu/home/news/)
    * [For Advertisers](https://www.allaboutbirds.org/news/for-advertisers/)
  * [Citizen Science](http://www.birds.cornell.edu/citsci/)
    * [eBird](https://ebird.org/home)
    * [Project Feederwatch](https://feederwatch.org/)
    * [NestWatch](https://nestwatch.org)
    * [Celebrate Urban Birds](https://celebrateurbanbirds.org/)
    * [Great Backyard Bird Count](http://gbbc.birdcount.org)
  * [Lifelong Learning](https://academy.allaboutbirds.org/course-list/)
    * [Online Courses](https://academy.allaboutbirds.org/)
    * [Bird Walks & Events](https://www.birds.cornell.edu/home/visit/events/)
    * [Spring Field Ornithology](https://academy.allaboutbirds.org/product/spring-field-ornithology-northeast/)
    * [K–12 Education](https://www.birds.cornell.edu/k12)
  * [Publications](https://www.birds.cornell.edu/home/publications/)
    * [Birds of the World](https://birdsoftheworld.org/bow/home)
    * [Clements Checklist](http://www.birds.cornell.edu/clementschecklist)
    * [State of the Birds](https://www.stateofthebirds.org/)
    * [Annual Report](https://www.birds.cornell.edu/home/annual-report/)
    * [Scientific Citations](https://www.birds.cornell.edu/home/publications/)
    * [Living Bird Magazine](https://www.allaboutbirds.org/news/living-bird-latest-issue/)
  * [Explore More](https://www.allaboutbirds.org/news/how-to-recognize-woodpeckers-by-their-drumming-sounds/)
    * [Bird Guide](https://www.allaboutbirds.org/guide/)
    * [Bird Cams](https://www.allaboutbirds.org/cams/)
    * [Macaulay Library](https://www.macaulaylibrary.org/)
    * [“Raven” Sound Analysis](http://ravensoundsoftware.com/)
    * [Our Youtube Videos](https://www.youtube.com/labofornithology)
    * [FAQs](https://www.allaboutbirds.org/news/browse/topic/faqs/)
  * [Support Our Cause](https://join.birds.cornell.edu/ea-action/action?ea.client.id=1806&ea.campaign.id=28635&ea.tracking.id=WEB)
    * [Join the Lab](https://join.birds.cornell.edu/page/150611/donate/1?ea.tracking.id=WXXXXX14C)
    * [Donate](https://give.birds.cornell.edu/page/87895/donate/1?ea.tracking.id=AAF)
    * [Monthly Giving](https://give.birds.cornell.edu/page/99134/donate/1?ea.tracking.id=WXXXXX01C&utm_source=BCE&utm_medium=Website&utm_campaign=Evergreen-Sustainer&utm_content=home-page)
    * [Membership Services](https://www.birds.cornell.edu/home/members/)
    * [Shop for Our Cause](https://www.birds.cornell.edu/home/shop-for-our-cause/)


  * [Contact Us](https://www.birds.cornell.edu/home/contact-us/)
  * [Web Accessibility Assistance](https://www.birds.cornell.edu/home/web-accessibility-assistance/)
  * [Privacy Policy](https://privacy.cornell.edu/information-use-cornell)
  * [Terms of use](https://www.birds.cornell.edu/home/terms-of-use/)
  * [Site Credits](https://www.allaboutbirds.org/news/site-credits/)


## Follow Us
  * [](https://facebook.com/cornellbirds "Like us on Facebook")
  * [](https://www.instagram.com/cornellbirds "Follow us on Instagram")
  * [](https://www.linkedin.com/company/cornell-lab-of-ornithology "Connect with us on LinkedIn")


![Cornell University](https://www.allaboutbirds.org/news/wp-content/themes/birdpress3/images/cornell-logo-white.svg)
© 2025 Cornell University
Close ×
Search for species name or keywords
Or Browse Bird Guide by [Family](https://www.allaboutbirds.org/guide/browse/taxonomy) or [Shape](https://www.allaboutbirds.org/guide/browse)
Need Bird ID Help? [Try Merlin](https://merlin.allaboutbirds.org)
Close ×
## Don't miss a thing! Join our email list
The Cornell Lab will send you updates about birds,   
birding, and opportunities to help bird conservation.
Email Address*
Close ×
[×](javascript:void\(0\) "Close dialog")
![Cornell Lab](https://lightbox.allaboutbirds.org/wp-content/plugins/clo-lightbox/logos/clo_nestwatch_horizontal.svg)
## Free Spring Warbler Guide
Brush up on eastern, western, and widespread warblers in time for spring migration with this handy photo guide.
[Your Warbler Guide](https://hubs.la/Q03f_SX30)
![A bright yellow bird perches on a twig. A sample view of the warbler guide hovers behind its head.](https://lightbox.allaboutbirds.org/wp-content/uploads/2025/04/150407951_htmlnativelightbox_3.jpg)Prothonotary Warbler by Martina Nordstrand / Macauley Library
