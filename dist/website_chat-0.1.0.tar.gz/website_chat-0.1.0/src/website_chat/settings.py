import os

DOC_DIR = os.path.dirname(os.path.abspath(__file__)) + "/.docs"
